cd src/compile
make
cd ../../
ln -sf ./src/compile/main .
./main






