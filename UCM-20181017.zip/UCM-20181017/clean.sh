#!/bin/bash

cd ./src/compile
make clean
cd ../../
rm src/compile/main
