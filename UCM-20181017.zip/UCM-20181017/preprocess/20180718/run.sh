rm a.out
gfortran read.f90
./a.out

