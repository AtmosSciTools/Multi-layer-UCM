#!/bin/sh


file2=kugahara_0901_$1.txt
file1=interpo_kugahara_0901_$1.txt

. ./plot2ex.gmt $file1 $file2
