rm a.out
ifort read.f90
./a.out

